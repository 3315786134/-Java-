package com.yang.utils;

import java.io.Serializable;

/**
 * 工具类；作为消息实体在网络上进行传输
 * @author Lenovo
 *
 */
public class Result implements Serializable{
	
	boolean success;
	String message;
	
	public Result() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Result(boolean success, String message) {
		super();
		this.success = success;
		this.message = message;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
