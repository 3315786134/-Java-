package com.yang.bean;

/**
 * 联系人表属性
 * @author Administrator
 */
public class Contactor {
	private int id;				//系统编号
	private int userId;			//用户ID
	private String name;		//姓名
	private String tel;			//电话
	private String address;		//地址
	private String zipcode;		//邮编
	
	//setter和getter代码
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
}