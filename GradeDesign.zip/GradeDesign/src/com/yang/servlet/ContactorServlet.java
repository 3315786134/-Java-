package com.yang.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.alibaba.fastjson.JSON;
import com.yang.bean.Contactor;
import com.yang.bean.User;
import com.yang.service.ContactorService;
import com.yang.service.UserService;
import com.yang.utils.CommonsUtils;
import com.yang.utils.Result;

/**
 * 处理联系人请求
 * @author Administrator
 */
public class ContactorServlet extends HttpServlet {
	//创建ContactorService对象
	private ContactorService cs = new ContactorService();
	//创建UserService对象
	private UserService us = new UserService();
	//定义用户ID
	private int userId;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	/**
	 * 通过获取表单中的隐藏字段method或者超链接中的method参数的值来区分调用执行哪个方法来处理这个请求
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String result="";
		
		// 处理中文乱码
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		// 获取隐藏字段method的值，并把它转换为int型
		int method = Integer.parseInt(request.getParameter("method"));

		switch (method) {
		case 1:
			this.register(request, response);				//用户注册
			break;
		case 2:
			this.login(request, response);					//用户登录
			break;
		case 3:
			this.query(request, response);					//显示所有的联系人信息		
			break;
		case 4:
			result = this.add(request, response);			//添加联系人
			break;
		case 5:
			this.loadForUpdate(request, response);			//处理加载某一个客户的请求	
			break;
		case 6:
			result = this.edit(request, response);			//修改联系人
			break;
		case 7:
			this.delete(request, response);					//删除联系人
			break;
		case 8:
			this.query1(request, response);					//条件查询
			break;
		case 9:
			result = this.checkCode(request, response);		//验证码验证
			break;
		}
		
		response.getWriter().write(result);
	}

	/**
	 * 验证码验证
	 * method = 9
	 * @param request
	 * @param response
	 */
	private String checkCode(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException  {
		//获取输入框中的验证码	
		String validateCode = request.getParameter("validateCode");
		//获取session中的验证码
		String reallyValidateCode =(String) request.getSession().getAttribute("sb");
		//比较两个验证码是否相同
		if(Objects.equals(validateCode, reallyValidateCode)) {
			return JSON.toJSONString(new Result(true,"验证通过"));
		}else {
			return JSON.toJSONString(new Result(false,"验证失败"));
		}
	}

	/**
	 * 处理注册的请求
	 * method = 1
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 使用CommonUtils工具类将请求数据封装到bean中
		User u = CommonsUtils.toBean(request.getParameterMap(), User.class);
		// 执行添加客户业务
		us.register(u);
		// 输出添加成功提示
		response.getWriter().print("注册成功,三秒钟自动跳转到登录界面");
		response.setHeader("Refresh", "3;url=http://localhost:8080/GradeDesign/jsp/login.jsp");
	}

	/**
	 * 处理登录的请求 
	 * method = 2
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//请求输入框中的用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		//请求输入框中的验证码
		String validateCode = request.getParameter("validateCode");
		//获取session中的验证码
		String reallyValidateCode =(String) request.getSession().getAttribute("sb");
		
		//将从数据库中查找到的数据封装成一个User类
		User u = us.login(username, password);
		if (u != null && Objects.equals(validateCode, reallyValidateCode)) {
			HttpSession session = request.getSession();
			//该方法用于将userId保存在session范围内
			session.setAttribute("userId", u.getId());
			response.getWriter().print("登录成功" + u.getId());
			//该方法用于获取保存在session范围内的UserId
			userId = (Integer) session.getAttribute("userId");
			//查询到属于userId的联系人信息，并存在list集合中
			List<Contactor> list = cs.load(userId);
			//将list存放到request域中
			request.setAttribute("contactorList", list);
			//请求跳转到list.jsp中
			request.getRequestDispatcher("/jsp/list.jsp").forward(request, response);
		} else {
			response.getWriter().print("登录失败，即将跳转到登录页面，请重新登录......");
			response.setHeader("Refresh", "3;url=http://localhost:8080/GradeDesign/jsp/login.jsp");

		}

	}

	/**
	 * 处理查看联系人的请求
	 * method=3
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void query(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//获取保存在session中的userId
		userId = (Integer) session.getAttribute("userId");
		//查询到属于userId的联系人，并存在list集合中
		List<Contactor> list = cs.load(userId);
		//将list存放到request域中
		request.setAttribute("contactorList", list);
		//System.out.println(list.size());
		//通过请求转发将查询结果带到list.jsp页面上显示
		request.getRequestDispatcher("/jsp/list.jsp").forward(request, response);
	}
	
	/**
	 * 处理姓名查询联系人的请求
	 * method = 8
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void query1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		//获取保存在session中的userId
		userId = (Integer) session.getAttribute("userId");
		//获取输入框中的姓名
		String name = request.getParameter("name");
		//执行条件查询业务
		List<Contactor> list = cs.load1(userId,name);
		//将list存放到request域中
		request.setAttribute("contactorList", list);
		//System.out.println(list.size());
		//通过请求转发将查询结果带到list.jsp页面上显示
		request.getRequestDispatcher("/jsp/list.jsp").forward(request, response);
	}

	/**
	 * 处理添加客户的请求
	 * method = 4
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public String add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		userId = (Integer) session.getAttribute("userId");
		
		//获取前端的数据
		String name = request.getParameter("name");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		String zipcode = request.getParameter("zipcode");
		Contactor c = new Contactor();
		c.setName(name);
		c.setAddress(address);
		c.setTel(tel);
		c.setZipcode(zipcode);
		//判断是否添加成功
		if(!cs.add(c, userId)) {
			//将Java对象转换为JSON字符串返回给前端页面
			return JSON.toJSONString(new Result(false,"添加失败"));
		}
		return JSON.toJSONString(new Result(true,"添加成功"));
	}

	/**
	 * 处理加载某一个客户的请求
	 * method = 5
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void loadForUpdate(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 从请求中获取联系人表中的id
		String ids = request.getParameter("id");
		int id = Integer.valueOf(ids);
		// 执行加载业务
		Contactor c = cs.loadById(id);
		// 将Contactor对象保存在request域中
		request.setAttribute("contactor", c);
		// 通过请求转发将Contactor对象显示在list.jsp页面上
		request.getRequestDispatcher("/jsp/list.jsp").forward(request, response);

	}

	/**
	 * 处理更改某一联系人的请求
	 * method = 6
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public String edit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		userId = (Integer) session.getAttribute("userId");
		
		//获取前端的数据
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		String zipcode = request.getParameter("zipcode");
		Contactor c = new Contactor();
		c.setId(Integer.parseInt(id));
		c.setName(name);
		c.setAddress(address);
		c.setTel(tel);
		c.setZipcode(zipcode);
		
		//判断是否成功修改
		if(!cs.edit(c, userId)) {
			//将Java对象转化为JSON字符串
			return JSON.toJSONString(new Result(false,"修改失败"));
		}
		return JSON.toJSONString(new Result(true,"修改成功"));
	}

	/**
	 * 处理删除某一联系人的请求
	 * method = 7
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	public void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 从请求中获取cid
		String cid = request.getParameter("id");
		int id = Integer.valueOf(cid);
		// 执行删除客户业务
		cs.delete(id);
		//调用query方法查看所有属于userId的联系人信息，并跳转到list.jsp页面
		new ContactorServlet().query(request, response);
	}

}