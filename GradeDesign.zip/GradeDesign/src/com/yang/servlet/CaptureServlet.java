package com.yang.servlet;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yang.utils.ImageUtil;

/**
 * 验证码servlet
 */
public class CaptureServlet extends HttpServlet{
 
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//创建图像
		/*BufferedImage是Image的一个子类，BufferedImage生成的图片在内存里有一个图像缓冲区，利用这个缓冲区
		     我们可以很方便的操作这个图片，通常用来做图片修改操作如大小变换、图片变灰、设置图片透明或不透明等。*/
		BufferedImage bi = ImageUtil.createImage(req.getSession(), 5);
		//以png格式   输出响应流到界面
		ImageIO.write(bi, "png", resp.getOutputStream());
		
		//设置浏览器不缓存图片
		resp.setHeader("Cache-Control", "no-cache");
		resp.setHeader("Pragma", "no-cache");
		resp.setDateHeader("expires", -1);
	}
	

}
